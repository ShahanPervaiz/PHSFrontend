import React, { useEffect } from "react";
import { Footer, Navbar, Sidebar, ThemeSettings } from "./components";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { FiSettings } from "react-icons/fi";
import { TooltipComponent } from "@syncfusion/ej2-react-popups";
import { useStateContext } from "./contexts/ContextProvider";
import Dashboard from "./pages/DashBoard/dashboard";
import Signin from "./pages/signin/signin";

export const App = () => {
  const {
    currentColor,
    setCurrentColor,
    currentMode,
    setCurrentMode,
    activeMenu, // Active menu from context
    themeSettings,
    setThemeSettings,
  } = useStateContext();

  return (
    <BrowserRouter>
      <Routes>
        {/* Pass activeMenu to Layout */}
        <Route path="/" element={<Signin />} />
        <Route path="dashboard" element={<Layout activeMenu={activeMenu}><Dashboard /></Layout>} />
      </Routes>
    </BrowserRouter>
  );
};

const Layout = ({ children, activeMenu }) => {
  return (
    <div className="flex relative dark:bg-main-dark-bg">
      {/* Sidebar */}
      {activeMenu ? (
        <div className="w-72 fixed sidebar dark:bg-secondary-dark-bg bg-white z-10">
          <Sidebar />
        </div>
      ) : (
        <div className="w-0 dark:bg-secondary-dark-bg">
          <Sidebar />
        </div>
      )}

      {/* Main content area */}
      <div
        className={
          activeMenu
            ? "dark:bg-main-dark-bg bg-main-bg min-h-screen md:ml-72 w-full"
            : "bg-main-bg dark:bg-main-dark-bg w-full min-h-screen flex-2"
        }
      >
        {/* Navbar - Changed to sticky */}
        <div className="sticky top-0 dark:bg-secondary-dark-bg bg-white  w-full z-50">
          <Navbar />
        </div>

        {/* Main content */}
        <div className="">{children}</div>

        <Footer />
      </div>
    </div>
  );
};
