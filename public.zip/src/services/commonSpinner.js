import React from 'react';
import { Oval } from 'react-loader-spinner';
import './commonspinner.css'
const CommonSpinner = () => {
  return (
    <div className="spinner-overlay">
      <Oval
        height={50}
        width={50}
        color="blue"
        visible={true}
        ariaLabel="oval-loading"
        secondaryColor="blue"
        strokeWidth={2}
        strokeWidthSecondary={2}
      />
    </div>
  );
};

export default CommonSpinner;
