import React, { useState, useEffect } from "react";
import { getRequest, postRequest } from "../../api/api";
import Accordion from "react-bootstrap/Accordion";

const Dashboard = () => {
  const [providers, setProviders] = useState([]);
  const [dictations, setDictations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [provider_id, setProviderId] = useState("");
  const [status, setStatus] = useState("");
  const [date, setDate] = useState("");

  useEffect(() => {
    const fetchProviders = async () => {
      try {
        const { data } = await getRequest("assistant_api/get-providers");
        // console.log("Data:", data);
        setProviders(data.providers || []);
      } catch (error) {
        console.error("Error fetching providers:", error.message);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProviders();
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    setLoading(true);
    const Payload = {
      provider_id: provider_id,
      status: status,
      date: date,
    };
    console.log("Payload", Payload);

    try {
      const response = await postRequest(
        "assistant_api/get-provider-dictations",
        Payload
      );
      setLoading(false);
      const result = response.data;
      console.log("dictations", result);
      setDictations(result.dictations || []);
      // if(result.message){
      // }else{

      // }
    } catch (error) {
      console.error("Error:", error);
    }
  };
  return (
    <div className="mt-3 p-2 md:p-10 bg-gray-200">
      <div className="card">
        <div className="card-header">
          <p>Welcome</p>
        </div>
        <form onSubmit={handleSearch}>
          <div className="card-body">
            {loading ? (
              <p>Loading...</p>
            ) : error ? (
              <p className="text-danger">Error: {error}</p>
            ) : (
              <div className="row">
                <div className="col-md-3">
                  <label
                    htmlFor="providerselect"
                    className="form-label"
                    style={{ minWidth: "100px" }}
                  >
                    Provider
                  </label>
                  <select
                    className="form-select"
                    aria-label="Default select example"
                    id="providerselect"
                    value={provider_id}
                    onChange={(e) => setProviderId(e.target.value)}
                    required
                  >
                    <option value="">Select Name</option>
                    {providers.map((provider) => (
                      <option key={provider.azz_id} value={provider.azz_id}>
                        {provider.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="col-md-3">
                  <label
                    htmlFor="datePicker"
                    className="form-label"
                    style={{ minWidth: "100px" }}
                  >
                    Date
                  </label>
                  <input
                    type="date"
                    className="form-control"
                    id="datePicker"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    required
                  />
                </div>
                <div className="col-md-3">
                  <label
                    htmlFor="statusSelect"
                    className="form-label"
                    style={{ minWidth: "100px" }}
                  >
                    Status
                  </label>
                  <select
                    className="form-select"
                    aria-label="Default select example"
                    id="statusSelect"
                    value={status}
                    onChange={(e) => setStatus(e.target.value)}
                    required
                  >
                    <option value=""> </option>
                    <option value="pending">Pending</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
                <div className="col-md-3 mt-4">
                  <button
                    type="submitt"
                    className="btn btn-primary"
                    style={{
                      backgroundColor: "#0d6efd",
                      color: "#fff",
                      border: "none",
                    }}
                  >
                    Search
                  </button>
                </div>
              </div>
            )}
          </div>
        </form>
      </div>
      {dictations.length > 0 && (
      <div className="card mt-4">
        <div className="card-header">
          <p>Dectations</p>
        </div>
        
        <div>
          {dictations.map((dictation, index) => (
            <div key={index} className="mt-3">
              <div className="row justify-content-center">
                <div className="col-md-3 mx-3">
                  <p className="text-uppercase">
                    <b>Patient Name:</b> {dictation.patient_name}
                  </p>
                </div>
                <div className="col-md-4 mx-3">
                <Accordion defaultActiveKey={['0']} alwaysOpen>
                  <Accordion.Item eventKey="1">
                    <Accordion.Header><b>Soap Note</b></Accordion.Header>
                    <Accordion.Body style={{ maxHeight: '150px', overflowY: 'auto', whiteSpace: 'pre-wrap' }}>
                      <p>{dictation.soap_note}</p>
                    </Accordion.Body>
                  </Accordion.Item>
                </Accordion>
                </div>
                <div className="col-md-3 mx-3">
                  <button className="btn btn-success">Mark As Done</button>
                </div>
              </div>
            </div>
          ))}
        </div>
     
        </div>
 )}
    </div>
  );
};

export default Dashboard;
