import React from "react";
import './dashboard.css';


const Dashboard = () => {
  
 
  return (
    <div>
      <p>Dashboard</p>
    </div>
  );
};

export default Dashboard;
