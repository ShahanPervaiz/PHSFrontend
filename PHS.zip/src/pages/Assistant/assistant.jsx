import React, { useState, useEffect } from "react";
import { getRequest, postRequest } from "../../api/api";
import { ToastContainer, toast } from 'react-toastify';
import { FaCheck } from "react-icons/fa";
import Accordion from "react-bootstrap/Accordion";
import { showToast } from '../../services/toastifyservices';
import { formatText } from "../../helper/index";
import CommonSpinner from '../../services/commonSpinner'

import './assistant.css';

const Assistant = () => {
    const [providers, setProviders] = useState([]);
    const [dictations, setDictations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [provider_id, setProviderId] = useState("");
    const [status, setStatus] = useState("");
    const [date, setDate] = useState("");

    useEffect(() => {
        const fetchProviders = async () => {
            try {
                const { data } = await getRequest("assistant_api/get-providers");
                // console.log("Data:", data);
                setProviders(data.providers || []);
            } catch (error) {
                console.error("Error fetching providers:", error.message);
                setError(error.message);
            } finally {
                setLoading(false);
            }
        };

        fetchProviders();
    }, []);

    const handleSearch = async (e) => {
        e.preventDefault();
        setLoading(true);
        const Payload = {
            provider_id: provider_id,
            status: status,
            date: date,
        };
        console.log("Payload", Payload);

        try {
            const response = await postRequest("assistant_api/get-provider-dictations", Payload);
            setLoading(false);
            const result = response.data;
            console.log("dictations", result);
            setDictations("");
            if (result.status) {
                showToast('success', '', result.message);
                // Check if soap_note has value, then format it
                const formattedDictations = result.dictations.map((dictation) => ({
                    ...dictation,
                    soap_note: dictation.soap_note ? formatText(dictation.soap_note) : dictation.soap_note
                }));
                setDictations(formattedDictations || []);
            } else {
                showToast('error', '', result.message);
            }
        } catch (error) {
            console.error("Error:", error);
        }
    };
    return (
        <div className="mt-3 p-2 md:p-10 bg-gray-200">
            <div className="card">
                <div className="card-header">
                    <h3 className="text-start text-primary-emphasis">Assistant</h3>
                </div>
                <form onSubmit={handleSearch}>
                    <div className="card-body">
                    <div className="row">
                                <div className="col-md-3">
                                    <label
                                        htmlFor="providerselect"
                                        className="form-label"
                                        style={{ minWidth: "100px" }}
                                    >
                                        Provider
                                    </label>
                                    <select
                                        className="form-select"
                                        aria-label="Default select example"
                                        id="providerselect"
                                        value={provider_id}
                                        onChange={(e) => setProviderId(e.target.value)}
                                        required
                                    >
                                        <option value="">Select Name</option>
                                        {providers.map((provider) => (
                                            <option key={provider.azz_id} value={provider.azz_id}>
                                                {provider.name}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-3">
                                    <label
                                        htmlFor="datePicker"
                                        className="form-label"
                                        style={{ minWidth: "100px" }}
                                    >
                                        Date
                                    </label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        id="datePicker"
                                        value={date}
                                        onChange={(e) => setDate(e.target.value)}
                                        required
                                    />
                                </div>
                                <div className="col-md-3">
                                    <label
                                        htmlFor="statusSelect"
                                        className="form-label"
                                        style={{ minWidth: "100px" }}
                                    >
                                        Status
                                    </label>
                                    <select
                                        className="form-select"
                                        aria-label="Default select example"
                                        id="statusSelect"
                                        value={status}
                                        onChange={(e) => setStatus(e.target.value)}
                                        required
                                    >
                                        <option value=""> </option>
                                        <option value="pending">Pending</option>
                                        <option value="completed">Completed</option>
                                    </select>
                                </div>
                                <div className="col-md-3 mt-4">

                                    <button className="btn btn-primary mt-2" type="submit">Search</button>

                                </div>
                            </div>
                    </div>
                </form>
            </div>
            {dictations.length > 0 && (
                <div className="mt-3">
                    {dictations.map((dictation, index) => (
                        <div key={index} className="card mb-3">
                            <div className="card-body">
                                <div className="row align-items-center">
                                    <div className="col-md-8">
                                        <p className="text-uppercase mb-0">
                                            <b>Patient Name:</b> {dictation.patient_name}
                                        </p>
                                    </div>
                                    <div className="col-md-4 text-end">
                                        <button className="btn btn-success d-inline-flex align-items-center">
                                            <FaCheck className="me-2" />
                                            <span>Mark As Done</span>
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-12">
                                    <Accordion defaultActiveKey="0" alwaysOpen className="custom-accordion">
                                        <Accordion.Item eventKey="1">
                                            <Accordion.Header><b>Soap Note</b></Accordion.Header>
                                            <Accordion.Body>
                                                {/* Rendering formatted HTML content using dangerouslySetInnerHTML */}
                                                <div
                                                    className="mb-0"
                                                    dangerouslySetInnerHTML={{ __html: dictation.soap_note }}
                                                ></div>
                                            </Accordion.Body>
                                        </Accordion.Item>
                                    </Accordion>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
            {loading && <CommonSpinner />}
            <ToastContainer />
        </div>
    );
};

export default Assistant;
