import React from 'react';
import { Oval } from 'react-loader-spinner';
import './commonspinner.css'
const CommonSpinner = () => {
  return (
    <div className="spinner-overlay flex flex-col items-center justify-center" style={{ height: '100vh' }}>
      <Oval
        height={50}
        width={50}
        color="blue"
        visible={true}
        ariaLabel="oval-loading"
        secondaryColor="blue"
        strokeWidth={9}
        strokeWidthSecondary={4}
      />
      <span className="text-blue-500 mt-2 text-lg">Loading...</span> {/* Blue colored loading text */}
    </div>
  );
};

export default CommonSpinner;
