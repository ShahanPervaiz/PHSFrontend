
# React-Admin-DashBoard

React Admin Dashboard is a stunning web application that has a beautiful user interface and has been built using advanced JavaScript concepts, React, and Tailwind CSS. This dashboard provides a comprehensive and intuitive user experience, allowing users to easily manage and track their data. React is a powerful JavaScript library that enables developers to build efficient and dynamic user interfaces, while Tailwind CSS provides a collection of pre-defined classes that make it easy to style and customize UI elements. The combination of these two technologies, along with advanced JavaScript concepts, makes for a highly responsive and engaging user experience. With React Admin Dashboard, users can stay on top of their data with ease and enjoy a visually pleasing interface.

This Project is hosted in Vercel : [React-Admin-DashBoard by Shivraj Gurjar](https://shiv-react-admin-dashboard.vercel.app/)

# Getting Started
These instructions will get you a copy of the project up and running on your local machine for development and testing purposes.

Prerequisites
Before you start, make sure you have the following software installed on your computer:

Node.js
npm (Node Package Manager)


## 🛠 Skills
Javascript, HTML, CSS, React.JS, and TailwindCSS.


## How to use this Repository?

1. Clone the repository to your local machine
2. Navigate to the project directory

```bash
  cd React-Admin-DashBoard
```
3. Install the necessary dependencies
```bash
  npm install
```

4. Start the development server
```bash
  npm start
```

The website should now be up and running on http://localhost:3000.

## Built With:

- React - A JavaScript library for building user interfaces
- Tailwind - A Modern CSS Framework.
- HTML - Standard markup language for creating web pages
- CSS - Style sheet language used for describing the look and formatting of a document written in HTML

## Features

- Light and Dark Mode.
- Theme Color Options.
- Responsive.
- Beautiful UI.
- Beautiful Graphs created using Syncfusion


## Tech Stack

**Client:** React, TailwindCSS, Syncfusion

**Server:** Vercel


## 🚀 About Me
Front - End Web Development Enthusiast
Specializations:
- UI/UX Design.
- Front-End Web Development

## Feedback

If you have any feedback, please reach out to me at iamshiv20032003@gmail.com


## Authors

- This project is made using tutorial of [Javascript Mastery](https://www.youtube.com/watch?v=_oO4Qi5aVZs&t=57s)

- [@Shivraj Gurjar](https://github.com/iamshiv007)

# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
